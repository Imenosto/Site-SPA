#ifndef __MENU_OPTION__
#define __MENU_OPTION__


#include "ensemble.h"
#include "envloppe_convexe.h"
#include "algorithme.h"

#include "calcul.h"
#include "liste_point.h"
#include "graphic.h"

/* les types */


/* les prototypes */
void menu();
void traitement_options(int argc, char* argv[]);
void execute_option(int input, int* nb_point, int* width, int* height);
void affich_menu();


void option_1(int nb_point, int width, int height);
void option_2(int nb_point, int width, int height);
void option_3(int nb_point, int width, int height);
void option_4(int nb_point, int width, int height);
void option_5(int nb_point, int width, int height);
void option_6(int nb_point, int width, int height);

void affichage_terminal(ConvexHull EC);

double perturb();
int minimum( int a, int b );
int maximum( int a, int b );


#endif