#include <stdio.h>
#include <stdlib.h>

#include "calcul.h"


/* la fonction qui met les points supprime dans une liste                                           */
void points_supprime( ListPoint* Ps, ConvexHull* EC, ConvexHull* EC_new ){
    int in = 1;
    for( int i=0;i<EC->curlen;i++ ){
        for( int j=0;j<EC_new->curlen;j++ ){
            if( EC->pol->s == EC_new->pol->s ){
                in = -1;
            }
            EC_new->pol = EC_new->pol->next;
        }
        if( in == 1 ){
            ajout_element_liste(Ps, EC->pol->s);
        }
        in = 1;
        EC->pol = EC->pol->next;
    }
}

/* la fonction qui met les points sans effet dans une liste                                         */
void points_sans_effet( ListPoint* R, Ensemble* Ens, ListPoint* Ps, ConvexHull* EC){
    for( int i=0;i<Ens->card;i++ ){
        /*verifier si le point appartient a l'envloppe convexe ou a la liste des points supprimee   */
        if( !( appartient_liste(Ps, &(Ens->tab[i])) || appartient_envloppe_convexe(EC, &(Ens->tab[i])) ) ){
            ajout_element_liste(R, &(Ens->tab[i]));
        }
    }
}

/* la fonction qui execute l'algorithme                                                             */
/* classifier les points de l'ensemble                                                              */
void calcul( ConvexHull* EC, Ensemble* Ens, ListPoint* Ps, ListPoint* R ){

    ConvexHull EC_new = init_envolppe_convexe();
    
    algorithme(Ens, &EC_new);

    points_supprime(Ps, EC,&EC_new);    

    algorithme(Ens, EC);

    points_sans_effet(R, Ens, Ps, EC);

    liberer_envoloppe_convex(&EC_new);

    return;
}

/* la fonction qui execute la fonction algorithme_2                                              */
void calcul_2( ConvexHull* EC, Ensemble* Ens, ListPoint* Ps, ListPoint* R ){

    ConvexHull EC_new = init_envolppe_convexe();
    
    copier_envloppe_convexe(&EC_new, EC);
    
    algorithme_2(Ens, EC);
    
    points_supprime(Ps, &EC_new, EC);    
    
    points_sans_effet(R, Ens, Ps, EC);
    
    liberer_envoloppe_convex(&EC_new);
    
    return;
}

/*
void calcul_2( ConvexHull* EC, Ensemble* Ens, ListPoint* Ps, ListPoint* R ){
    printf("CALCUL2\n");

    ConvexHull EC_new = init_envolppe_convexe();
    
    copier_envloppe_convexe(&EC_new, EC);
    
    algorithme_2(Ens, &EC_new);
    
    points_supprime(Ps, EC,&EC_new);    
    
    algorithme_2(Ens, EC);
    
    points_sans_effet(R, Ens, Ps, EC);
    
    liberer_envoloppe_convex(&EC_new);
    
    return;
}
*/