#ifndef __CALCUL__
#define __CALCUL__

#include "ensemble.h"
#include "envloppe_convexe.h"
#include "algorithme.h"
#include "liste_point.h"


/* les types */

/* les prototypes */
void points_supprime( ListPoint* Ps, ConvexHull* EC, ConvexHull* EC_new );
void points_sans_effet( ListPoint* R, Ensemble* Ens, ListPoint* Ps, ConvexHull* EC);

void calcul( ConvexHull* EC, Ensemble* Ens, ListPoint* Ps, ListPoint* R );
void calcul_2( ConvexHull* EC, Ensemble* Ens, ListPoint* Ps, ListPoint* R );

#endif