#include <stdio.h>

#include "ensemble.h"
#include "envloppe_convexe.h"
#include "algorithme.h"


/* next (->)                    */ 
/* (a, b, c) indirect           */ 
void nettoyage_avant( ConvexHull* EC){
    Polygon tmp = EC->pol;
    for( ;orientation_triangle(*(tmp->s), *(tmp->next->s), *(tmp->next->next->s)) == -1; ){
        suppression_Point(EC, tmp->next->s);
    }
}

/* prev (<-)            */ 
/* (a, c, b) indirect   */ 
void nettoyage_arrier( ConvexHull* EC ){
    Polygon tmp = EC->pol;
    for( ;orientation_triangle(*(tmp->s), *(tmp->prev->prev->s), *(tmp->prev->s)) == -1; ){
        suppression_Point(EC, tmp->prev->s);
    }
    
}

/* le triangle (a, b, c)    */ 
/* (1):direct (-1):indirect */ 

int orientation_triangle( Point a, Point b, Point c){
    Point u = vecteur(a, b);
    Point v = vecteur(a, c);

    if( (u.x * v.y) - (u.y * v.x) >= 0.0 ){
        return 1;
    }else{
        return -1;
    }
}

/* retourne le vecteur forme par a et b */ 
Point vecteur( Point a, Point b ){
    Point tmp;
    tmp.x = b.x - a.x;
    tmp.y = b.y - a.y;
    return tmp;
}

/* (1):si P est a l'exterieur de l'envloppe convexe     */
/* (0):sinon                                            */ 
int est_exterieur( ConvexHull* EC, Point P ){
    for( int i=0; i<EC->curlen;i++ ){
        if( orientation_triangle( *(EC->pol->s), *(EC->pol->next->s), P) == -1 ){
            return 1;
        }
        EC->pol = EC->pol->next;
    }
    return 0;
}


/* l'algorithme pour construire l'envloppe convex       */
void algorithme( Ensemble* Ens, ConvexHull* EC ){
    /* assurer que les elements de l'envloppe est vide  */
    liberer_envoloppe_convex(EC);

    /* le cas ou le nombre de points inferieur a 3      */
    if( Ens->card < 3 ){
        for(int i=0;i<Ens->card;i++){
            ajout_Point(EC, &(Ens->tab[i]));
        }
        increment_maxlen(EC);
        return;
    }
    /* Initialisation par un triangle                   */
    ajout_Point(EC, &(Ens->tab[0]));
    if( orientation_triangle(Ens->tab[0], Ens->tab[1], Ens->tab[2] ) == 1 ){
        ajout_Point(EC, &(Ens->tab[1]));
        ajout_Point(EC, &(Ens->tab[2]));
    }else{
        ajout_Point(EC, &(Ens->tab[2]));
        ajout_Point(EC, &(Ens->tab[1]));
    }
    increment_maxlen(EC);

    /* Traitement d'un point                            */
    /* appartir de l'indice 4                           */ 

    for( int i=3;i<Ens->card;i++ ){
        if( est_exterieur(EC, Ens->tab[i]) ){
            ajout_Point(EC, &(Ens->tab[i]));
            nettoyage_avant(EC);
            nettoyage_arrier(EC);
            increment_maxlen(EC);
        }
    }
}


/* un deuxieme algorithme pour l'envloppe convexe                                               */
/* la raison c'est que le premier devient tres lent car il rfait tous le calcul                 */

void algorithme_2( Ensemble* Ens, ConvexHull* EC ){

    if( Ens->card - 1 < 0 ){
        return;
    }

    if( Ens->card - 1  < 3 ){
        ajout_Point(EC, &(Ens->tab[Ens->card - 1]));
        increment_maxlen(EC);
        return;
    }

    if( est_exterieur(EC, Ens->tab[Ens->card - 1]) ){
        ajout_Point(EC, &(Ens->tab[Ens->card - 1]));
        nettoyage_avant(EC);
        nettoyage_arrier(EC);
        increment_maxlen(EC);
    }
}