#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "ensemble.h"
#include "envloppe_convexe.h"
#include "algorithme.h"
#include "calcul.h"
#include "liste_point.h"
#include "graphic.h"

#include "menu_option.h"



/* MENU */
void menu(){
    int input = 0;
    int nb_point = DEFAUT; // DEFAUT = 1000
    int width = 400;
    int height = 500;

    while( input != -1 ){
        affich_menu();
        scanf(" %d",&input);
        execute_option(input, &nb_point, &width, &height);
    }
}

/* la fonction qui affiche le menu  */
void affich_menu(){
    printf("********************\n");
    printf("***** MENU V1 ******\n");
    printf("********************\n");

    printf("[ ]  * affichage dynamique :                                                 \n");
    printf("[1]  * * la souris                                                           \n");
    printf("[2]  * * distribution pseudo-spirale Cercle                                  \n");
    printf("[3]  * * distribution pseudo-spirale Carre                                   \n");
    printf("[ ]  * affichage terminal :                                                  \n");
    printf("[4]  * * la souris                                                           \n");
    printf("[5]  * * distribution pseudo-spirale Cercle                                  \n");
    printf("[6]  * * distribution aleatoire                                              \n");
    
    printf("[7]  changer la taille de l'ecran               (par defaut 400x500 pixel)   \n");
    printf("[8]  changer le nombre de point dans l'ensemble (par defaut 1000 points)     \n");

    printf("[0]  retourne au valeur par defaut                                           \n");

    printf("[-1] quiter                                                                  \n");

    printf("choisisez une option [x] : ");
}

void execute_option(int input, int* nb_point, int* width, int* height){
    switch( input ){
        case  1 : option_1(*nb_point, *width, *height); break;
        case  2 : option_2(*nb_point, *width, *height); break;
        case  3 : option_3(*nb_point, *width, *height); break;

        case  4 : option_4(*nb_point, *width, *height); break;
        case  5 : option_5(*nb_point, *width, *height); break;
        case  6 : option_6(*nb_point, *width, *height); break;

        case  7 : printf("inserez (width, height) : ")      ; scanf(" %d %d", width,height); break;
        case  8 : printf("inserez le nombre de points : ")  ; scanf(" %d", nb_point)       ; break;
    
        case  0 : *nb_point = DEFAUT; *width = 400; *height=500; break;

        case -1 : /* RIEN */ ; break;

        default : printf("l'option que vous venez de choisir n'existe pas\n"); break;
    }
}



/* la fonction les option et les argument de la ligne de commande   */
void traitement_options(int argc, char* argv[]){
    if( argc <= 1 ){
        return;
    }
    int nb_point = DEFAUT; // DEFAUT = 1000
    int width = 400;
    int height = 500;
    int _o = 0;

    for( int i=1;i<argc;i++ ){
        if( strcmp( argv[i], "-t" ) == 0 ){
            width  = atoi(argv[i+1]);
            height = atoi(argv[i+2]);
        }
        if( strcmp( argv[i], "-n" ) == 0 ){
            nb_point = atoi(argv[i+1]);
        }
        if( strcmp( argv[i], "-o" ) == 0 ){
            _o = i+1;
        }
    }

    char* c = argv[_o];
    switch( *c ){
        case '1': execute_option(1, &nb_point, &width, &height); break;
        case '2': execute_option(2, &nb_point, &width, &height); break;
        case '3': execute_option(3, &nb_point, &width, &height); break;
        case '4': execute_option(4, &nb_point, &width, &height); break;
        case '5': execute_option(5, &nb_point, &width, &height); break;
        case '6': execute_option(6, &nb_point, &width, &height); break;
    }
}

/* la fonction ajoute une petit peturbabtion pour un point  */
double perturb(){
    double PERTURB = 0.0001/RAND_MAX;
    return (rand()%2?+1.:-1.)*PERTURB*rand();
}

/* la fonction qui affiche les information sur terminal     */
void affichage_terminal(ConvexHull EC){
    printf("*************************************\n");
    printf("information sur l'envloppe convexe : \n");
    printf("longeur courant : %d\n", EC.curlen      );
    printf("longeur maximal : %d\n", EC.maxlen      );
    
    printf("next (->) : \n");
    for( int i=0;i<EC.curlen;i++ ){
        printf("(%.2f,%.2f)->",EC.pol->s->x, EC.pol->s->y );
        EC.pol = EC.pol->next;
    }
    printf("\n");

    printf("prev (<-) : \n");
    for( int i=0;i<EC.curlen;i++ ){
        printf("(%.2f,%.2f)->",EC.pol->s->x, EC.pol->s->y );
        EC.pol = EC.pol->prev;
    }
    printf("\n");
    printf("*************************************\n");
    
    int input;
    printf("[0] retourner : ");
    scanf(" %d", &input);
}

/* retourner le minimum entre a et b                        */
int minimum( int a, int b ){
    if( a < b ){
        return a;
    }
    return b;
}

/* retourner le maximum entre a et b                        */
int maximum( int a, int b ){
    if( a > b ){
        return a;
    }
    return b;
}

/*=======================================================================*/
/*  les fonction ci-desuous s'execute en fonction des option choisi      */
/*=======================================================================*/

/* [1] */
void option_1(int nb_point, int width, int height){
    ConvexHull EC = init_envolppe_convexe();
    Ensemble  Ens = init_ensemble();
    ListPoint  Ps = init_liste(nb_point);
    ListPoint   R = init_liste(nb_point);

    MLV_Event K = MLV_NONE;
    int x,y;
    Point p;

    alloue_ensemble(&Ens, nb_point);

    MLV_create_window("A", "B", width, height);

    clear();

    while( K != MLV_KEY ){
        K = MLV_wait_keyboard_or_mouse( NULL, NULL, NULL, &x, &y );
                
        if( K == MLV_MOUSE_BUTTON ){
            MLV_clear_window( MLV_COLOR_WHITE );

            p.x = (double)x + perturb();
            p.y = (double)y + perturb();

            ajout_element(&Ens, p);
            calcul( &EC, &Ens, &Ps, &R );
            draw( EC, Ps, R );

            MLV_update_window();
        }
    }

    MLV_free_window();

    liberer_envoloppe_convex(&EC);
    liberer_ensemble(&Ens);
    liberer_liste(&Ps);
    liberer_liste(&R);
}

/* [2] */
void option_2(int nb_point, int width, int height){
    ConvexHull EC = init_envolppe_convexe();
    Ensemble  Ens = init_ensemble();
    ListPoint  Ps = init_liste(nb_point);
    ListPoint   R = init_liste(nb_point);
    
    Point p;
    int rayon = 10;
    
    int r;
    double theta;
    
    int min = minimum( width/2, height/2 );
    int nb_etap = min/5;
    int nbp = maximum( nb_point/nb_etap, 1 );

    alloue_ensemble(&Ens, nb_point);

    MLV_create_window("A", "B", width, height);
    clear();

    for( int i=0;i<nb_point;i++ ){        
        MLV_clear_window( MLV_COLOR_WHITE );

        r = (int)sqrt(rand()%(rayon*rayon));
        theta = (rand()%(31415 * 2))/10000.;

        p.x = (double)(width/2. ) + ( r * cos(theta) ) + perturb();
        p.y = (double)(height/2.) + ( r * sin(theta) ) + perturb();

        ajout_element(&Ens, p);
        calcul_2( &EC, &Ens, &Ps, &R );
        draw( EC, Ps, R );

        MLV_draw_circle( width/2, height/2, rayon, MLV_COLOR_MAGENTA );
        MLV_update_window();
        
        rayon = minimum( maximum( ((i)/nbp) * 5 , 10 ), min );
    }

    MLV_wait_keyboard_or_mouse( NULL, NULL, NULL, NULL, NULL );
    MLV_free_window();

    liberer_envoloppe_convex(&EC);
    liberer_ensemble(&Ens);
    liberer_liste(&Ps);
    liberer_liste(&R);
}

/* [3] */
void option_3(int nb_point, int width, int height){
    ConvexHull EC = init_envolppe_convexe();
    Ensemble  Ens = init_ensemble();
    ListPoint  Ps = init_liste(nb_point);
    ListPoint   R = init_liste(nb_point);
    
    Point p;
    int T = 10;
    int r1,r2;
    int min = minimum( width/2, height/2 );
    int nb_etap = min/5;
    int nbp = maximum( nb_point/nb_etap, 1);

    alloue_ensemble(&Ens, nb_point);

    MLV_create_window("A", "B", width, height);
    clear();

    for( int i=0;i<nb_point;i++ ){        
        MLV_clear_window( MLV_COLOR_WHITE );

        r1 = rand()%(T * 2) - T;
        r2 = rand()%(T * 2) - T;

        p.x = (double)(width/2. ) + r1 + perturb();
        p.y = (double)(height/2.) + r2 + perturb();
        ajout_element(&Ens, p);

        calcul_2( &EC, &Ens, &Ps, &R );
        draw( EC, Ps, R );

        MLV_draw_rectangle( (width/2)-T, (height/2)-T, 2*T, 2*T, MLV_COLOR_MAGENTA );
        MLV_update_window();
        
        T = minimum( maximum( ((i)/nbp) * 5 , 10 ), min );
    }

    MLV_wait_keyboard_or_mouse( NULL, NULL, NULL, NULL, NULL );
    MLV_free_window();

    liberer_envoloppe_convex(&EC);
    liberer_ensemble(&Ens);
    liberer_liste(&Ps);
    liberer_liste(&R);
}

/* [4] */
void option_4(int nb_point, int width, int height){
    ConvexHull EC = init_envolppe_convexe();
    Ensemble  Ens = init_ensemble();
    ListPoint  Ps = init_liste(nb_point);
    ListPoint   R = init_liste(nb_point);

    MLV_Event K = MLV_NONE;
    int x,y;
    Point p;

    alloue_ensemble(&Ens, nb_point);

    MLV_create_window("A", "B", width, height);

    clear();

    while( K != MLV_KEY ){
        K = MLV_wait_keyboard_or_mouse( NULL, NULL, NULL, &x, &y );
                
        if( K == MLV_MOUSE_BUTTON ){
            p.x = (double)x + perturb();
            p.y = (double)y + perturb();

            ajout_element(&Ens, p);

            MLV_draw_filled_circle( x, y, 3, MLV_COLOR_BLACK );
            MLV_update_window();
        }
    }

    MLV_free_window();
    
    algorithme(&Ens, &EC);    
    affichage_terminal(EC);

    liberer_envoloppe_convex(&EC);
    liberer_ensemble(&Ens);
    liberer_liste(&Ps);
    liberer_liste(&R);
}

/* [5] */
void option_5(int nb_point, int width, int height){
    ConvexHull EC = init_envolppe_convexe();
    Ensemble  Ens = init_ensemble();

    Point p;
    int rayon = 10;
    double theta;
    int r;

    int min = minimum( width/2, height/2 );
    int nb_etap = min/5;
    int nbp = maximum( nb_point/nb_etap, 1 );

    alloue_ensemble(&Ens, nb_point);

    MLV_create_window("A", "B", width, height);
    clear();
    MLV_draw_circle( width/2, height/2, min, MLV_COLOR_MAGENTA );

    for( int i=0;i<nb_point;i++ ){
        r = (int)sqrt(rand()%(rayon*rayon));
        theta = (rand()%(31415 * 2))/10000.;

        p.x = (double)(width/2. ) + (r * cos(theta)) + perturb();
        p.y = (double)(height/2.) + (r * sin(theta)) + perturb();
        ajout_element(&Ens, p);

        MLV_draw_filled_circle( (int)p.x, (int)p.y, 3, MLV_COLOR_BLACK );
        MLV_update_window();

        rayon = minimum( maximum( ((i)/nbp) * 5 , 10 ), min );
    }

    MLV_wait_keyboard_or_mouse( NULL, NULL, NULL, NULL, NULL );
    MLV_free_window();
    
    algorithme(&Ens, &EC);    
    affichage_terminal(EC);

    liberer_envoloppe_convex(&EC);
    liberer_ensemble(&Ens);
}

/* [6] */
void option_6(int nb_point, int width, int height){
    ConvexHull EC = init_envolppe_convexe();
    Ensemble  Ens = init_ensemble();
    
    Point p;
    int x,y;

    alloue_ensemble(&Ens, nb_point);

    MLV_create_window("A", "B", width, height);
    clear();

    for( int i=0;i<nb_point;i++ ){        

        x = rand()%width;
        y = rand()%height;

        p.x = (double)x + perturb();
        p.y = (double)y + perturb();
        ajout_element(&Ens, p);

        MLV_draw_filled_circle( x, y, 3, MLV_COLOR_BLACK );
        MLV_update_window();
        
    }

    MLV_wait_keyboard_or_mouse( NULL, NULL, NULL, NULL, NULL );
    MLV_free_window();

    algorithme(&Ens, &EC);    
    affichage_terminal(EC);

    liberer_envoloppe_convex(&EC);
    liberer_ensemble(&Ens);
}


