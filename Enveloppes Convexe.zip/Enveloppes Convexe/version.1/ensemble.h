#ifndef __ENSEMBLE__
#define __ENSEMBLE__

#define DEFAUT 1000



/* les types        */

/* le type Point    */ 
typedef struct _point {
    double x;
    double y;
}Point;

// le type Ensemble
typedef struct _ensemble{
    Point* tab;             /* un tableau dynamique des points      */ 
    int card;               /* le nombre de points dans l'ensemble  */ 
    int taille;             /* la taille de tab                     */ 
}Ensemble;


/* les prototypes   */

Ensemble init_ensemble();
void alloue_ensemble(Ensemble* e, int n);
int appartient_ensemble(Ensemble, Point);
void ajout_element(Ensemble*, Point);
void liberer_ensemble(Ensemble*);



#endif
