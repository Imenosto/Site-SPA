clang -c -std=c17  -Wall -Wfatal-errors main.c
clang -c -std=c17  -Wall -Wfatal-errors ensemble.c
clang -c -std=c17  -Wall -Wfatal-errors envloppe_convexe.c
clang -c -std=c17  -Wall -Wfatal-errors algorithme.c
clang -c -std=c17  -Wall -Wfatal-errors liste_point.c
clang -c -std=c17  -Wall -Wfatal-errors calcul.c
clang -c -std=c17  -Wall -Wfatal-errors menu_option.c
clang -c -std=c17  -Wall -Wfatal-errors graphic.c



clang -o prog -std=c17 -lMLV -Wall -Wfatal-errors main.o ensemble.o envloppe_convexe.o algorithme.o liste_point.o calcul.o menu_option.o graphic.o -lm
