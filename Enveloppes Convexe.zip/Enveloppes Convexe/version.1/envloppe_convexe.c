#include <stdio.h>
#include <stdlib.h>

#include "ensemble.h"

#include "envloppe_convexe.h"

/* allouer un sommet (Vertex)                                           */
Polygon alloueVertexe(Point* p){
    Polygon tmp = (Polygon)malloc(sizeof(Vertex));
    if( tmp == NULL ){
        printf("echec d'alocation !\n");
        exit(1);
    }
    tmp->prev = NULL;
    tmp->next = NULL;
    tmp->s = p;

    return tmp;
}

/* initiliser une envloppe convexe                                      */
ConvexHull init_envolppe_convexe(){
    ConvexHull tmp;
    tmp.pol = NULL;
    tmp.curlen = 0;
    tmp.maxlen = 0;
    
    return tmp;
}

/* inserer un sommet a l'envloppe convexe                               */
void insert_Vertex( ConvexHull* EC, Vertex* v ){
    if( EC->curlen == 0 ){
        EC->pol = v;

        EC->pol->next = EC->pol;
        EC->pol->prev = EC->pol;

        EC->curlen = 1;
        

        return;
    }
    v->next = EC->pol->next;
    v->prev = EC->pol;

    EC->pol->next->prev = v;
    EC->pol->next = v;
    
    EC->pol = v;
    EC->curlen ++;
}

/* verifier si un point appartient a l'envloppe convexe ou non          */
/* 1 pour oui , 0 pour non                                              */
int appartient_evloppe_convexe( ConvexHull EC, Point* p){
    Polygon tmp = EC.pol;
    for(int i=0;i<EC.curlen; i++){
        if( tmp->s == p ){
            return 1;
        }
        tmp = tmp->next;
    }
    return 0;
}

/* inserer un point a l'envloppe convexe                                */
void ajout_Point( ConvexHull* EC, Point* p ){
    if( appartient_evloppe_convexe(*EC, p) ){
        return;
    }
    Vertex* v = alloueVertexe(p);
    
    insert_Vertex(EC, v);
}

/* supprimer un vertex dans un envloppe convex                          */
void suppression_Vertex( ConvexHull* EC, Vertex* v){
    if( EC->pol == v ){
        EC->pol = EC->pol->next;
    }
    if( EC->curlen == 1 ){
        EC->pol = NULL;
    }

    v->next->prev = v->prev;
    v->prev->next = v->next;

    
    v->next = NULL;
    v->prev = NULL;
    v->s = NULL;

    free(v);

    EC->curlen -= 1;
    
}

/* supprimer un point dans un envloppe convex                           */
void suppression_Point( ConvexHull* EC, Point* p){
    Vertex* tmp = EC->pol;
    for(int i=0;i<EC->curlen;i++){
        if( tmp->s == p ){
            suppression_Vertex(EC, tmp);
            return;
        }
        tmp = tmp->next;
    }
    
}

/* incrementer la longeur maximum de l'envloppe                         */
void increment_maxlen( ConvexHull* EC ){
    if( EC->maxlen < EC->curlen){
        EC->maxlen = EC->curlen;
    }
}


/* liberer la memoire alloue par l'envloppe convex                      */
void liberer_envoloppe_convex( ConvexHull* EC ){
    while( EC->pol ){
        suppression_Vertex( EC, EC->pol );
    }
    *EC = init_envolppe_convexe();
}

/* verifier si un point appartient a l'envloppe convexe                 */
/* 1:OUI  et 0:NON                                                      */
int appartient_envloppe_convexe( ConvexHull* EC, Point* p ){
    Polygon tmp = EC->pol;
    for( int i=0;i<EC->curlen;i++ ){
        if( tmp->s == p ){
            return 1;
        }
        tmp = tmp->next;
    }
    return 0;
}

/* copier un envloppe convexe                                           */
void copier_envloppe_convexe( ConvexHull* A, ConvexHull* B ){
    for( int i=0;i<B->curlen;i++ ){    
        ajout_Point(A, B->pol->s);
        B->pol = B->pol->next;
    }
}