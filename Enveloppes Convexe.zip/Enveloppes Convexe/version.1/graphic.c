#include <stdio.h>
#include <stdlib.h>
#include <MLV/MLV_all.h>

#include "ensemble.h"
#include "envloppe_convexe.h"
#include "liste_point.h"

#include "graphic.h"


/* l'affichage graphique */
void draw( ConvexHull EC, ListPoint Ps, ListPoint R ){
    draw_polygon(EC);
    draw_class_point(EC, Ps, R);
}

/* la fonction qui dessine le polygone de l'envloppe convexe    */
void draw_polygon(ConvexHull EC){
    Polygon tmp = EC.pol;

    int* tbx;
    int* tby;
    tbx = (int*)malloc(EC.curlen * sizeof(int));
    tby = (int*)malloc(EC.curlen * sizeof(int));

    if( tbx == NULL || tby == NULL ){
        printf("echec d'allocation!\n");
        exit(1);
    }
    
    for(int i=0;i<EC.curlen;i++,tmp=tmp->next){
        tbx[i]=(int)tmp->s->x;
        tby[i]=(int)tmp->s->y;
    }
    MLV_draw_filled_polygon(tbx, tby, EC.curlen, MLV_rgba(0, 200, 100, 30));
    MLV_draw_polygon(tbx, tby, EC.curlen, MLV_rgba(0, 0, 0, 255));

    free(tbx);
    free(tby);
}

/* dessiner les points (orange) (rouge) (bleu)  */
void draw_class_point( ConvexHull EC, ListPoint Ps, ListPoint R ){
    for( int i=0;i<R.card;i++ ){
        MLV_draw_filled_circle( (int)(R.p[i])->x, (int)(R.p[i])->y, 3, MLV_COLOR_BLUE );
    }

    for( int i=0;i<Ps.card;i++ ){
        MLV_draw_filled_circle( (int)(Ps.p[i])->x, (int)(Ps.p[i])->y, 3, MLV_COLOR_ORANGE );
    }

    draw_point_env_convexe(EC, MLV_COLOR_RED);
}

/* la fonction qui dessine les points de l'encloppe convexe     */
void draw_point_env_convexe( ConvexHull EC, MLV_Color color ){
    Polygon tmp = EC.pol;
    for( int i=0;i<EC.curlen;i++ ){
        MLV_draw_filled_circle( (int)tmp->s->x, (int)tmp->s->y, 3, color );
        tmp = tmp->next;
    }
}

/* netoyer la fenetre */
void clear(){
    MLV_clear_window(MLV_COLOR_WHITE);
    MLV_update_window();
}