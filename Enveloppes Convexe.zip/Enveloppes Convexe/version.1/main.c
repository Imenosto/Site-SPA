#include <stdio.h>

#include "menu_option.h"




int main(int argc, char* argv[]){
    
    traitement_options( argc, argv );
    
    menu();

    printf("EXIT\n");
    
    return 0;
}
