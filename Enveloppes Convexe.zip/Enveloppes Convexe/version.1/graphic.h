#ifndef __GRAPHIC__
#define __GRAPHIC__

#include <MLV/MLV_all.h>
#include "ensemble.h"
#include "envloppe_convexe.h"
#include "liste_point.h"

/* les types        */


/* les prototypes   */

void draw( ConvexHull EC, ListPoint Ps, ListPoint R );

void draw_polygon(ConvexHull EC);
void draw_class_point( ConvexHull EC, ListPoint Ps, ListPoint R );
void draw_point_env_convexe( ConvexHull EC, MLV_Color color );
void clear();

#endif