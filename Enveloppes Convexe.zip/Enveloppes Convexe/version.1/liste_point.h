#ifndef __LISTE_POINT__
#define __LISTE_POINT__

#include "ensemble.h"
#include "envloppe_convexe.h"


/* les types      */

typedef struct _list_point{
    Point** p;              /* tableau de pointeur de type (Point*) */
    int card;               /* le cardinal de la liste des points   */
}ListPoint;

/* les prototypes */

ListPoint init_liste( int n );
void liberer_liste(ListPoint* LP);
int appartient_liste( ListPoint* LP, Point* p );
void ajout_element_liste( ListPoint* LP, Point* p );

#endif
