Cherrak Imen   TD 1
Tounsi Mourad  TD 5

###############
## Partie 1  ##
###############


Commandes à exécuter, disponible dans le fichier comp.sh de VERSION1:

[1] clang -c -std=c17  -Wall -Wfatal-errors main.c
[2] clang -c -std=c17  -Wall -Wfatal-errors ensemble.c
[3] clang -c -std=c17  -Wall -Wfatal-errors envloppe_convexe.c
[4] clang -c -std=c17  -Wall -Wfatal-errors algorithme.c
[5] clang -c -std=c17  -Wall -Wfatal-errors liste_point.c
[6] clang -c -std=c17  -Wall -Wfatal-errors calcul.c
[7] clang -c -std=c17  -Wall -Wfatal-errors menu_option.c
[8] clang -c -std=c17  -Wall -Wfatal-errors graphic.c

[9] clang -o prog -std=c17 -lMLV -Wall -Wfatal-errors -lm main.o ensemble.o envloppe_convexe.o algorithme.o liste_point.o calcul.o menu_option.o graphic.o

-L'ordre n'est pas important pour l’exécution des 8 premières commandes,   
  cependant la commande [9] doit être la dernière.

-Les commandes [1] à [8] génèrent un fichier.o pour chaque fichier.c (objet)

-La commande [9] va générer un fichier exécutable ( programme )

-Deux manières possibles de lancer le projet :

** Ligne de commande ** 

- 3 options en ligne de commande ( -t -n -o ) :

    • -t : changer la taille de la fenêtre MlV (400 x 500 par défaut)
    • -n : modifier le nombre de points de l’ensemble (1000 points par défaut)
    • -o : choisir l’option à exécuter (numérotées de 1 à 6)

- Exemples :
	./prog -t 500 500 -n 2000 -o 2 
	./prog -o 1
	./prog -n 200 -o 3
              
** MENU **

- Il suffit d’exécuter le programme (./prog), puis le menu s’affiche. Après avoir choisis l’option, il suffit d’appuiyer sur la touche « Entrée »

- Pour quitter une option on clic sur une touche du clavier

- Les options dans la partie ** affichage sur le terminal ** permettent de suivre l’évolution du convexe selon l’option choisie.

###############
## Partie 2  ##
############### 

-Nous avons modifié un peu les structures de la (partie 1)

Commandes à exécuter, disponible dans le fichier comp.sh de VERSION2:

[1] clang -c -std=c17  -Wall -Wfatal-errors main.c
[2] clang -c -std=c17  -Wall -Wfatal-errors ensemble.c
[3] clang -c -std=c17  -Wall -Wfatal-errors envloppe_convexe.c
[4] clang -c -std=c17  -Wall -Wfatal-errors algorithme.c
[5] clang -c -std=c17  -Wall -Wfatal-errors liste_point.c
[6] clang -c -std=c17  -Wall -Wfatal-errors menu_option.c
[7] clang -c -std=c17  -Wall -Wfatal-errors graphic.c
[8] clang -c -std=c17  -Wall -Wfatal-errors recursive.c


[9] clang -o prog -std=c17 -lMLV -Wall -Wfatal-errors main.o ensemble.o envloppe_convexe.o algorithme.o liste_point.o  menu_option.o graphic.o recursive.o -lm

-L'ordre n'est pas important pour l’exécution des 8 premières commandes,   
  cependant la commande [9] doit être la dernière.

-Les commandes [1] à [8] génèrent un fichier.o pour chaque fichier.c (objet)

-La commande [9] va générer un fichier exécutable ( programme )

** EXÉCUTION DU PROGRAMME **

-Exécuter le programme (./prog)

-Un menu avec toute les options s’affichent

-Pour l’option [3] :
    • Il vous est demandé de choisir un chiffre entre 4 (forme rectangle) et 11 (forme cercle), plus le chiffre se rapproche du nombre 11 plus le résultat prendra la forme d’un cercle.









