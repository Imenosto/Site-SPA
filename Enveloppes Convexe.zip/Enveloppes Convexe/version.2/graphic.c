#include <stdio.h>
#include <stdlib.h>
#include <MLV/MLV_all.h>

#include "envloppe_convexe.h"

#include "graphic.h"

/* la fonction qui dessine pour les options recurssive */
void draw( ConvexHull* EC ){
    int i = 0;
    int R,G,B;
    for( ;EC;EC=EC->next ){
        i = (i)%6 + 1;
        
        R = (i%2        )/1 ;
        G = (i%4 - R    )/2 ;
        B = (i   - R - G)/4 ;

        draw_polygon(*EC, R, G, B );
        draw_point_env_convexe(*EC, R, G, B );
    }
}



/* la fonction qui dessine le polygone de l'envloppe convexe */
void draw_polygon(ConvexHull EC, int R, int G, int B ){
    Polygon tmp = EC.pol;

    int* tbx;
    int* tby;
    tbx = (int*)malloc(EC.curlen * sizeof(int));
    tby = (int*)malloc(EC.curlen * sizeof(int));

    if( tbx == NULL || tby == NULL ){
        printf("echec d'allocation!\n");
        exit(1);
    }
    
    for(int i=0;i<EC.curlen;i++,tmp=tmp->next){
        tbx[i]=(int)tmp->s->x;
        tby[i]=(int)tmp->s->y;
    }
    MLV_draw_filled_polygon(tbx, tby, EC.curlen, MLV_rgba(255*R, 255*G, 255*B, 80));
    MLV_draw_polygon(tbx, tby, EC.curlen, MLV_rgba(255*R, 255*G, 255*B, 255));

    free(tbx);
    free(tby);
}



/* la fonction qui dessine les points de l'encloppe convexe */
void draw_point_env_convexe( ConvexHull EC, int R, int G, int B ){
    MLV_Color color = MLV_rgba(255*R, 255*G, 255*B, 255);
    Polygon tmp = EC.pol;
    for( int i=0;i<EC.curlen;i++ ){
        MLV_draw_filled_circle( (int)tmp->s->x, (int)tmp->s->y, 3, color );
        tmp = tmp->next;
    }
}