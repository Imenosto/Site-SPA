#ifndef __ENVLOPPE_CONVEXE__
#define __ENVLOPPE_CONVEXE__

#include "ensemble.h"

/* les types */
typedef struct _point Point;

/* structure du polygone */
typedef struct _vrtx_ {
    Point* s;                       /* un point de l’ensemble */ 
    struct _vrtx_ *prev;            /* le vertex précédent */ 
    struct _vrtx_ *next;            /* le vertex suivant */ 
} Vertex, *Polygon; 

/* structure du polygone convex */
typedef struct _convexhull_{
    Polygon pol;                    /* le polygône */
    int curlen;                     /* la longueur courante */
    int maxlen;                     /* la longueur maximale */

    struct _convexhull_* next;      /* la version.2 (pour creer une liste chainee d'enveloppe) */
} ConvexHull;

/* les prototypes */
Polygon alloueVertexe(Point* p);
ConvexHull init_envolppe_convexe();
void insert_Vertex( ConvexHull* EC, Vertex* v );
int appartient_evloppe_convexe( ConvexHull EC, Point* p);
void ajout_Point( ConvexHull* EC, Point* p );
void suppression_Vertex( ConvexHull* EC, Vertex* v);
void suppression_Point( ConvexHull* EC, Point* p);
void increment_maxlen( ConvexHull* EC );
void liberer_envoloppe_convex( ConvexHull* EC );
int appartient_envloppe_convexe( ConvexHull* EC, Point* p );

void copier_envloppe_convexe( ConvexHull* A, ConvexHull* B );

/* les fonction de laversion.2 */
void alloue_Enveloppe( ConvexHull** LEC );
void insert_Enveloppe( ConvexHull** PLEC, ConvexHull* EC );
void liberer_liste_envlope( ConvexHull** PLEC );

#endif