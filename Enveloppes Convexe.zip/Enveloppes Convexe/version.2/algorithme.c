#include <stdio.h>

#include "algorithme.h"
#include "ensemble.h"
#include "liste_point.h"

#include "envloppe_convexe.h"


// ->next
// (a, b, c) indirect
void nettoyage_avant( ConvexHull* EC){
    Polygon tmp = EC->pol;
    for( ;orientation_triangle(*(tmp->s), *(tmp->next->s), *(tmp->next->next->s)) == -1; ){
        //ajout_element_liste( LP, tmp->next->s );
        suppression_Point(EC, tmp->next->s);
    }
}

// ->prev
// (a, c, b) indirect
void nettoyage_arrier( ConvexHull* EC ){
    Polygon tmp = EC->pol;
    for( ;orientation_triangle(*(tmp->s), *(tmp->prev->prev->s), *(tmp->prev->s)) == -1; ){
        //ajout_element_liste( LP, tmp->next->s );
        suppression_Point(EC, tmp->prev->s);
    }
    
}

// le triangle (a, b, c)
// 1:direct -1:indirect

int orientation_triangle( Point a, Point b, Point c){
    Point u = vecteur(a, b);
    Point v = vecteur(a, c);

    if( (u.x * v.y) - (u.y * v.x) >= 0.0 ){
        return 1;
    }else{
        return -1;
    }
}

// retourne le vecteur forme par a et b
Point vecteur( Point a, Point b ){
    Point tmp;
    tmp.x = b.x - a.x;
    tmp.y = b.y - a.y;
    return tmp;
}

// 1:si P est a l'exterieur de l'envloppe convexe
// sinon 0
int est_exterieur( ConvexHull* EC, Point P ){
    for( int i=0; i<EC->curlen;i++ ){
        if( orientation_triangle( *(EC->pol->s), *(EC->pol->next->s), P) == -1 ){
            return 1;
        }
        EC->pol = EC->pol->next;
    }
    return 0;
}

/* l'algorithme pour construire l'envloppe convex */
void algorithme( ListPoint* LP, ConvexHull* EC ){
    /* assurer que les elements de l'envloppe sont inisialisé   */
    liberer_envoloppe_convex(EC);

    /* le cas ou le nombre de points inferieur a 3 */
    if( LP->card < 3 ){
        for(int i=0;i<LP->card;i++){
            ajout_Point(EC, LP->p[i]);
        }
        increment_maxlen(EC);
        return;
    }
    
    /* Initialisation                                       */
    /* initialiser avec un triangle afin qu'il soit direct  */
    ajout_Point(EC, LP->p[0]);
    if( orientation_triangle( *(LP->p[0]) , *(LP->p[1]), *(LP->p[2]) ) == 1 ){
        ajout_Point(EC, LP->p[1]);
        ajout_Point(EC, LP->p[2]);
        
    }else{
        ajout_Point(EC, LP->p[2] );
        ajout_Point(EC, LP->p[1] );

        
    }
    increment_maxlen(EC);

    /* Traitement d'un point d'indice > 3 */
    for( int i=3;i<LP->card;i++ ){
        if( est_exterieur(EC, *(LP->p[i]) ) ){
            ajout_Point(EC, LP->p[i] );
            nettoyage_avant(EC);
            nettoyage_arrier(EC);
            increment_maxlen(EC);
        }
    }
}

