#include <stdio.h>
#include <stdlib.h>

#include "menu_option.h"

int main(int argc, char* argv[]){
    
    traitement_options(argc, argv);
    menu();
    printf("FIN\n");

    return 0;
}
