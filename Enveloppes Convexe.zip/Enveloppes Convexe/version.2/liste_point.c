#include <stdio.h>
#include <stdlib.h>

#include "liste_point.h"

/* initialisation d'une liste et allocation */
ListPoint init_liste( int n ){
    ListPoint tmp;
    tmp.card = 0;
    tmp.taille = n;
    tmp.p = (Point**)malloc(n * sizeof(Point*));
    if( tmp.p == NULL ){
        printf("echec d'alocation !\n");
        exit(1);
    }
    return tmp;
}

/* liberer une liste de points */
void liberer_liste(ListPoint* LP){
    free(LP->p);
    LP->p = NULL;
    LP->card = 0;
    LP->taille = 0;
}

/* verifier si un point appartient a la liste des points LP */
int appartient_liste( ListPoint* LP, Point* p ){
    for( int i=0;i<LP->card;i++ ){
        if( LP->p[i] == p ){
            return 1;
        }
    }
    return 0;
}

/* fonction qui ajoute un point a liste des points */
void ajout_element_liste( ListPoint* LP, Point* p ){
    for( int i=0;i<LP->card;i++ ){
        if( p == LP->p[i] ){
            return;
        }
    }
    LP->p[LP->card] = p;
    LP->card++;
}

/*********************************/
/* les fonctions de la version.2 */
/*********************************/

/* remplir la liste avec les element de lensemble */
void copy_ensemble_liste( Ensemble* Ens, ListPoint* LP ){
    for( int i=0;i<Ens->card;i++ ){
        ajout_element_liste( LP, &(Ens->tab[i]) );
    } 
}

/* la fonction retourne les points qui n'appartient pas a l'enveloppe convexe ( EC\LP )*/
void difference_envloppe_liste( ListPoint* LP_FINAL, ListPoint* LP, ConvexHull* EC ){
    int in = 1;
    for( int i=0;i<LP->card;i++ ){
        for( int j=0;j<EC->curlen;j++ ){
            if( EC->pol->s == LP->p[i] ){
                in = 0;
            }
            EC->pol = EC->pol->next;
        }
        if( in == 1 ){
            ajout_element_liste( LP_FINAL, LP->p[i] );
        }
        in = 1;
    }
}