#ifndef __ALGORITHME__
#define __ALGORITHME__

#include "ensemble.h"
#include "envloppe_convexe.h"
#include "liste_point.h"

/* les types */


/* les prototypes */

int orientation_triangle( Point a, Point b, Point c);
Point vecteur( Point a, Point b );
int est_exterieur( ConvexHull* EC, Point P );
void nettoyage_avant( ConvexHull* EC);
void nettoyage_arrier( ConvexHull* EC );

void algorithme( ListPoint* LP, ConvexHull* EC );



#endif

