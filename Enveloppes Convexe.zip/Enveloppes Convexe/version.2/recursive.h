#ifndef __RECURSIVE__
#define __RECURSIVE__


#include "ensemble.h"
#include "envloppe_convexe.h"
#include "algorithme.h"

#include "liste_point.h"
#include "graphic.h"

/* les types */

/* les prototypes */
void algorithme_recursif( ConvexHull** PLEC, ListPoint* LP );



#endif
