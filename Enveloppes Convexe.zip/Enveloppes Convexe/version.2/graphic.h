#ifndef __GRAPHIC__
#define __GRAPHIC__

#include <MLV/MLV_all.h>

#include "envloppe_convexe.h"


/* les types */


/* les prototypes */
void draw( ConvexHull* EC );
void draw_polygon(ConvexHull EC, int R, int G, int B );
void draw_point_env_convexe( ConvexHull EC, int R, int G, int B );


#endif