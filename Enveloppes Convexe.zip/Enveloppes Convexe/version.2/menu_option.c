#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <MLV/MLV_all.h>

#include "ensemble.h"
#include "envloppe_convexe.h"
#include "algorithme.h"

#include "liste_point.h"
#include "graphic.h"
#include "recursive.h"

#include "menu_option.h"



/* MENU */
void menu(){
    int input = 0;
    int nb_point = DEFAUT; // DEFAUT = 1000
    int width = 400;
    int height = 500;

    while( input != -1 ){
        affich_menu();
        scanf(" %d",&input);
        execute_option(input, &nb_point, &width, &height);
    }
}

/* la fonction qui affiche le menu  */
void affich_menu(){
    printf("********************\n");
    printf("***** MENU V2 ******\n");
    printf("********************\n");

    printf("[1]  souris(1) (nuage de points)    (clic clavier pour sortir)  \n");
    printf("[2]  souris(2)                      (clic souris pour sortir)   \n");
    printf("[3]  spirale polygone (4~11)        (clic clavier pour sortir)  \n");
    
    printf("[4]  VIDE      \n");
    printf("[5]  VIDE      \n");
    printf("[6]  VIDE      \n");
    
    printf("[7]  changer la taille de l'ecran               (par defaut 400x500 pixel)   \n");
    printf("[8]  changer le nombre de point dans l'ensemble (par defaut 500 points)      \n");

    printf("[0]  retourne au valeur par defaut                                           \n");

    printf("[-1] quiter                                                                  \n");

    printf("choisisez une option [x] : ");
}

void execute_option(int input, int* nb_point, int* width, int* height){
    switch( input ){
        case  1 : option_1(*nb_point, *width, *height); break;
        case  2 : option_2(*nb_point, *width, *height); break;
        case  3 : option_3(*nb_point, *width, *height); break;

        case  4 : option_4(*nb_point, *width, *height); break;
        case  5 : option_5(*nb_point, *width, *height); break;
        case  6 : option_6(*nb_point, *width, *height); break;

        case  7 : printf("inserez (width, height) : ")      ; scanf(" %d %d", width,height) ; break;
        case  8 : printf("inserez le nombre de points : ")  ; scanf(" %d", nb_point)        ; break;
    
        case  0 : *nb_point = DEFAUT; *width = 400; *height=500; break;

        case -1 : /* RIEN */ ; break;

        default : printf("l'option que vous venez de choisir n'existe pas\n"); break;
    }
}



/* la fonction les option et les argument de la ligne de commande   */
void traitement_options(int argc, char* argv[]){
    if( argc <= 1 ){
        return;
    }
    int nb_point = DEFAUT; // DEFAUT = 1000
    int width = 400;
    int height = 500;
    int _o = 0;

    for( int i=1;i<argc;i++ ){
        if( strcmp( argv[i], "-t" ) == 0 ){
            width  = atoi(argv[i+1]);
            height = atoi(argv[i+2]);
        }
        if( strcmp( argv[i], "-n" ) == 0 ){
            nb_point = atoi(argv[i+1]);
        }
        if( strcmp( argv[i], "-o" ) == 0 ){
            _o = i+1;
        }
    }

    char* c = argv[_o];
    switch( *c ){
        case '1': execute_option(1, &nb_point, &width, &height); break;
        case '2': execute_option(2, &nb_point, &width, &height); break;
        case '3': execute_option(3, &nb_point, &width, &height); break;
        case '4': execute_option(4, &nb_point, &width, &height); break;
        case '5': execute_option(5, &nb_point, &width, &height); break;
        case '6': execute_option(6, &nb_point, &width, &height); break;
    }
}

/* la fonction ajoute une petit peturbabtion pour un point  */
double perturb(){
    double PERTURB = 0.0001/RAND_MAX;
    return (rand()%2?+1.:-1.)*PERTURB*rand();
}

/* retourner le minimum entre a et b                        */
int minimum( int a, int b ){
    if( a < b ){
        return a;
    }
    return b;
}

/* retourner le maximum entre a et b                        */
int maximum( int a, int b ){
    if( a > b ){
        return a;
    }
    return b;
}

/* retourner la distance entre deux points A et B*/
int distance( Point A, Point B ){
    return sqrt((A.x-B.x)*(A.x-B.x)+(A.y-B.y)*(A.y-B.y));
}

/*=======================================================================*/
/*  les fonction ci-desuous s'execute en fonction des option choisi      */
/*=======================================================================*/

/* [1] */
void option_1(int nb_point, int width, int height){
    ConvexHull* LEC = NULL;
    Ensemble Ens = init_ensemble();
    ListPoint LP;
    Point p;
    int x,y;
    MLV_Event K = MLV_NONE;

    alloue_ensemble( &Ens, nb_point );
    LP = init_liste(Ens.taille);
    
    MLV_create_window("A", "B", width, height);
    MLV_draw_filled_rectangle(0,0,width,height, MLV_COLOR_WHITE);
    MLV_update_window();

    while( K != MLV_KEY){
        MLV_draw_filled_rectangle(0,0,width,height,MLV_COLOR_WHITE);

        K = MLV_wait_keyboard_or_mouse(NULL,NULL,NULL,&x,&y);

        if( K == MLV_MOUSE_BUTTON ){
            p.x = (double)x + perturb();
            p.y = (double)y + perturb();
            ajout_element( &Ens, p );
            copy_ensemble_liste( &Ens, &LP );

            algorithme_recursif(&LEC, &LP);
        }

        draw(LEC);
        MLV_update_window();
        liberer_liste_envlope( &LEC );
    }

    MLV_free_window();

    liberer_ensemble(&Ens);
    liberer_liste(&LP);
    liberer_liste_envlope( &LEC );
}

/* [2] */
void option_2(int nb_point, int width, int height){
    ConvexHull* LEC = NULL;
    Ensemble Ens = init_ensemble();
    ListPoint LP;
    int x,y;
    int run = 1;

    alloue_ensemble( &Ens, 11 );
    Point pt[6]={
        {width*(1/6.),height*(1/6.)},
        {width*(2/6.),height*(3/6.)},
        {width*(3/6.),height*(2/6.)},
        {width*(4/6.),height*(2/6.)},
        {width*(1/6.),height*(5/6.)},
        
        {width*(2/6.),height*(2/6.)}
        };
    ajout_element(&Ens, pt[0]);
    ajout_element(&Ens, pt[1]);
    ajout_element(&Ens, pt[2]);
    ajout_element(&Ens, pt[3]);
    ajout_element(&Ens, pt[4]);
    ajout_element(&Ens, pt[5]);

    LP = init_liste(Ens.taille);
    
    MLV_create_window("A", "B", width, height);
    MLV_change_frame_rate(60);
    MLV_draw_filled_rectangle(0,0,width,height, MLV_COLOR_WHITE);
    MLV_update_window();

    while( run == 1){
        MLV_draw_filled_rectangle(0,0,width,height,MLV_COLOR_WHITE);
        
        MLV_get_mouse_position(&x, &y);
        Ens.tab[5].x = (double)x ;
        Ens.tab[5].y = (double)y ;
            
        copy_ensemble_liste( &Ens, &LP );
        algorithme_recursif(&LEC, &LP);
        
        draw(LEC);
        MLV_update_window();
        liberer_liste_envlope( &LEC );

        if( MLV_get_mouse_button_state(MLV_BUTTON_LEFT) == MLV_PRESSED ){
            run = 0;
        }
    }

    MLV_free_window();

    liberer_ensemble(&Ens);
    liberer_liste(&LP);
    liberer_liste_envlope( &LEC );
}


/* [3] */
void option_3(int nb_point, int width, int height){
    ConvexHull* LEC = NULL;
    Ensemble Ens = init_ensemble();
    ListPoint LP;
    Point p;

    alloue_ensemble( &Ens, nb_point );
    LP = init_liste(Ens.taille);
    
    int nbp = 11;

    printf("inserer un entier entre [4 et 11] : ");
    scanf(" %d",&nbp);
    nbp = maximum(minimum(nbp,11), 4);
    
    int M = nb_point - nb_point%nbp;
    int r = 50;
    double theta = 2*(3.1415) / nbp;
    double cte = 0.;
    int MIN = minimum(height, width)/2;
    Point centre = {width/2,height/2};

    MLV_create_window("A", "B", width, height);
    MLV_draw_filled_rectangle(0,0,width,height, MLV_COLOR_WHITE);
    MLV_update_window();

    for( int i=0;i<M && r < MIN;i++ ){
        MLV_draw_filled_rectangle(0,0,width,height, MLV_COLOR_WHITE);
        
        p.x = (double)(r * cos(i * theta + cte)) + (width/2);
        p.y = (double)(r * sin(i * theta + cte)) + (height/2);
        ajout_element( &Ens, p );
        copy_ensemble_liste( &Ens, &LP );
        algorithme_recursif(&LEC, &LP);

        if( (i+1)%nbp == 0 ){
            r+= distance(centre, *(LP.p[LP.card-1]))/(nbp-1);
            cte += 3.1415/12;
        }

        draw(LEC);
        MLV_update_window();
        MLV_wait_milliseconds(100);
        liberer_liste_envlope( &LEC );
    }
    
    MLV_wait_keyboard_or_mouse(NULL,NULL,NULL,NULL,NULL);
    MLV_free_window();

    liberer_ensemble(&Ens);
    liberer_liste(&LP);
    liberer_liste_envlope( &LEC );

}

/* [4] */
void option_4(int nb_point, int width, int height){
    
}

/* [5] */
void option_5(int nb_point, int width, int height){
    
}

/* [6] */
void option_6(int nb_point, int width, int height){
    
}


