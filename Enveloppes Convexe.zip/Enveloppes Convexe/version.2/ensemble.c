#include <stdio.h>
#include <stdlib.h>

#include "ensemble.h"

/* initialiser un ensemble                                                  */ 
Ensemble init_ensemble(){
    Ensemble tmp;
    tmp.tab = NULL;
    tmp.card = 0;
    tmp.taille = 0;

    return tmp;
}

/* alloue un espace necessaire pour la table des points d'un ensemble       */
void alloue_ensemble(Ensemble* e, int n){
    
    e->tab = (Point*)malloc(n*sizeof(Point));
    e->taille = n;
    
    if(e->tab == NULL){
        printf("erreur dans alloue_ensemble(). echec d'allocation\n");
        exit(1);
    }
}

/* libere l'espace allouee pour l'ensemble                                  */
void liberer_ensemble(Ensemble* e){
    free(e->tab);
    *e = init_ensemble();
}

/* verifie si oui ou non un element appartient a l'ensemble                 */
/* 1:OUI  et 0:NON                                                          */
/* l'erreur d'approximation est 0,0000000000000001                          */ 
int appartient_ensemble(Ensemble e, Point p){
    for(int i=0;i<e.card;i++){
        if( p.x == e.tab[i].x && p.y == e.tab[i].y ){
            return 1;
        }
    }
    return 0;
}

/* ajouter un point dans un ensemble                                        */
void ajout_element(Ensemble* e, Point p){
    if( appartient_ensemble(*e,p) ){
        return;
    }
    if( e->card < e->taille ){
        e->tab[e->card].x = p.x;
        e->tab[e->card].y = p.y;
        e->card +=1;
    }
    
}