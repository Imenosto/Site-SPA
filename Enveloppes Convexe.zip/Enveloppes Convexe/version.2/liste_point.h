#ifndef __LISTE_POINT__
#define __LISTE_POINT__

#include "ensemble.h"
#include "envloppe_convexe.h"
//#include "algorithme.h"

/* les types */
/* une nouveau type pour faciliter le travail avec les points d'ensemble */
typedef struct _list_point{
    Point** p;                  /* un tableau de points* qui pointes vers les les points d'ensemble */
    int card;                   /* le nombre d'elements */
    int taille;                 /* la taille du tableau */
}ListPoint;

/* les prototypes */
ListPoint init_liste( int n );
void liberer_liste(ListPoint* LP);
int appartient_liste( ListPoint* LP, Point* p );
void ajout_element_liste( ListPoint* LP, Point* p );

/* les fonctions de la version.2 */
void copy_ensemble_liste( Ensemble* Ens, ListPoint* LP );
void difference_envloppe_liste( ListPoint* LP_FINAL, ListPoint* LP, ConvexHull* EC );

#endif