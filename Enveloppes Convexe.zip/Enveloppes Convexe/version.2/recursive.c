#include <stdio.h>
#include <MLV/MLV_all.h>

#include "ensemble.h"
#include "envloppe_convexe.h"
#include "algorithme.h"

#include "liste_point.h"
#include "graphic.h"

#include "recursive.h"


void algorithme_recursif( ConvexHull** PLEC, ListPoint* LP ){
    if( LP->card == 0){
        return;
    }
    ConvexHull* EC_tmp;
    
    alloue_Enveloppe(&EC_tmp);
    
    algorithme( LP, EC_tmp );

    ListPoint LP_tmp = init_liste(LP->taille);

    difference_envloppe_liste( &LP_tmp, LP, EC_tmp );

    insert_Enveloppe( PLEC, EC_tmp );

    algorithme_recursif( PLEC, &LP_tmp );
    
    liberer_liste(&LP_tmp);
    
    return;
}

