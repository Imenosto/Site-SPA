from flask import Flask, render_template, request, redirect, url_for, session
import db
import random

import time
import datetime

#from utils.mem import *


app = Flask(__name__)

#===============================================================================
# Clef secrète utilisée pour chiffrer les cookies
app.secret_key = b'd2b01c987b6f7f0d5896aae06c4f318c9772d6651abff24aec19297cdf5eb199'

#===============================================================================
@app.route("/")
def deb():
    return redirect(url_for("accueil"))

@app.route("/accueil")
def accueil():
    print("---------------")
    if "log_in" in session:
        return redirect(url_for("mode_personne_SPA"))
    return render_template("accueil.html")

#===============================================================================
# mode visiteur :
@app.route("/mode_visiteur")
def mode_visiteur():
    if "log_in" in session:
        return redirect(url_for("mode_personne_SPA"))
    return render_template("mode_visiteur.html")
#===============================================================================
# personne SPA :
@app.route("/page_connexion")
def page_connexion():
    if "log_in" in session:
        return redirect(url_for("mode_personne_SPA"))
    return render_template("page_connexion.html")

@app.route("/verification", methods = ['POST'])
def var():
    log_in = request.form.get("log", None)
    mdp = request.form.get("mdp", None)

    with db.connect() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM employe WHERE log_in = %s AND mot_de_passe = %s",(log_in,mdp))
            output = cur.fetchone()

    if not output:
        return redirect(url_for("page_erreur"))
    session["log_in"] = log_in

    print(log_in)
    print(mdp)
    print(output)
    print("-->"+session["log_in"])
    
    return redirect(url_for("mode_personne_SPA"))
#===============================================================================
@app.route("/page_erreur")
def page_erreur():
    if "log_in" in session:
        return redirect(url_for("mode_personne_SPA"))
    return render_template("page_erreur.html")
#===============================================================================
@app.route("/mode_personne_SPA")
def mode_personne_SPA():
    if "log_in" in session:
        # initialiser la variable gloable etap
        #initialise()
        # obtenir le nom et le prenom de l'utilisateur
        with db.connect() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT nom,prenom FROM employe WHERE log_in = %s",(session["log_in"],))
                output = cur.fetchone()

        return render_template("mode_personne_SPA.html", output_ = output)
    return redirect(url_for("page_connexion"))


#===============================================================================
@app.route("/deconnexion")
def log_out():
    if "log_in" in session:
        session.pop("log_in")
    return redirect(url_for("page_connexion"))

#===============================================================================
# recherche visite
selected = None
@app.route("/recherche_visiteur")
def recherche_visiteur():
    if "log_in" in session:
        return redirect(url_for("mode_personne_SPA"))

    global selected
    l_output = None
    l_output_s1 = None
    l_output_s2 = None

    # selectionner un code postal
    with db.connect() as conn:
        with conn.cursor() as cur:
            cur.execute(" SELECT DISTINCT code_postal FROM refuge ")
            l_code_postal = cur.fetchall()
    
    #print(l_code_postal[0])
    #print(l_code_postal[0][0])
    #print(selected)

    # pas de selection
    if not selected:
        with db.connect() as conn:
            with conn.cursor() as cur:
                # le nombre de refuge a afficher est limite a 20
                cur.execute("""
                                SELECT * 
                                FROM refuge
                                ORDER BY code_postal
                                LIMIT 20
                            """)
                l_output = cur.fetchall()
    else :
        with db.connect() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                                SELECT * 
                                FROM refuge
                                WHERE code_postal = %s
                                ORDER BY code_postal
                            """,(selected,))
                l_output_s1 = cur.fetchall()

                # le nombre de refuge a afficher est limite a 20
                cur.execute("""
                                SELECT * 
                                FROM refuge
                                WHERE code_postal <> %s
                                ORDER BY code_postal
                                LIMIT 20
                            """,(selected,))
                l_output_s2 = cur.fetchall()
    

    return render_template("recherche_visiteur.html", l_output_ = l_output, l_code_postal_ = l_code_postal, l_output_s1_ = l_output_s1, l_output_s2_ = l_output_s2)

@app.route("/get_code_postal", methods = ['POST'])
def get_code_postal():
    global selected
    var_get = request.form.get("cod_post",None)
    print(var_get)
    selected = var_get
    if selected == "":
        selected = None
    return redirect(url_for("recherche_visiteur"))


@app.route("/list_animal_refuge/<int:pid>")
def list_animal_refuge(pid):
    if "log_in" in session:
        return redirect(url_for("mode_personne_SPA"))
    
    with db.connect() as conn:
        with conn.cursor() as cur:
            cur.execute("""
                        SELECT * 
                        FROM arrive NATURAL JOIN animal
                        WHERE (idANI,date_) IN
                            (
                                SELECT idANI,MAX(date_)
                                FROM arrive
                                GROUP BY idANI
                            )
                        AND idREF = %s;
                        """,(pid,))
            l_output = cur.fetchall()
            cur.execute("SELECT * FROM refuge WHERE idREF = %s ;",(pid,))
            output = cur.fetchone()
    
    return render_template("list_animal_v.html",l_output_=l_output, output_ = output)

#===============================================================================
@app.route("/list_ani_non_vac_ps")
def list_ani_non_vac_ps():
    if "log_in" not in session:
        return redirect(url_for("page_connexion"))

    with db.connect() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM v1")
            l_output = cur.fetchall()
    return render_template("list_ani_non_vac_ps.html", l_output_ = l_output)

#===============================================================================
@app.route("/list_ani_rapp_ps")
def list_ani_rapp_ps():
    if "log_in" not in session:
        return redirect(url_for("page_connexion"))
    with db.connect() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM v2")
            l_output = cur.fetchall()
    return render_template("list_ani_rapp_ps.html", l_output_ = l_output)

#===============================================================================
etap = 0

select_table = None
select_attribu = None
ordonner = None
ordre = None
limit = None
output = None


list_attrib = None
@app.route("/lecture_ps")
def lecture_ps():
    if "log_in" not in session:
        return redirect(url_for("page_connexion"))
    
    global etap
    global select_table
    global select_attribu
    global ordonner
    global ordre
    global limit
    global output
    

    nom_table = [
        "animal",
        "refuge",
        "employe",
        "soin",
        "particulier",
        "historique",
        "occupe",
        "arrive",
        "depart"
    ]

    
    
    if etap == 1 :
        if select_table == "animal":
            select_attribu = ["idani", "espece", "nom", "age", "sexe", "signes_dist", "fourriere_dorigine", "date_rejoint_spa"]
        elif select_table == "refuge":
            select_attribu = ["idref", "nom", "code_postal", "adresse", "num_tele", "capacite", "matricule"]
        elif select_table == "employe":
            select_attribu = ["matricule", "nom", "prenom", "adresse", "num_tele", "date_naiss", "num_sec", "date_arrive_spa"]
        elif select_table == "soin":
            select_attribu = ["idsoi", "nom"]
        elif select_table == "particulier":
            select_attribu = ["idpar", "nom", "prenom", "adresse", "num_tele"]
        elif select_table == "historique":
            select_attribu = ["idani", "idsoi", "matricule", "date_"]
        elif select_table == "occupe":
            select_attribu = ["idref", "matricule", "nom_de_fonction"]
        elif select_table == "arrive":
            select_attribu = ["idani", "idref", "date_"]
        elif select_table == "depart":
            select_attribu = ["idani", "idref", "date_"]
        
        if select_table == "-- liste des tables --":
            etap = 0
    
    if etap == 10:
        S = ""
        T = ""
        for i in range(0,len(select_attribu),1):
            S += select_attribu[i]
            if i+1 < len(select_attribu):
                S += ","
        for i in range(0,len(ordonner),1):
            T += ordonner[i]
            if i+1 < len(ordonner):
                T += ","
    
        with db.connect() as conn:
            with conn.cursor() as cur:
                if len(ordonner) == 0 and limit == "NO" :
                    cur.execute("SELECT "+ S +" FROM " + select_table + "")
                elif len(ordonner) != 0 and limit == "NO" :
                    cur.execute("SELECT "+ S +" FROM " + select_table + " ORDER BY (" + T +") "+ ordre + "")
                elif len(ordonner) == 0 and limit != "NO" :
                    cur.execute("SELECT "+ S +" FROM " + select_table + " LIMIT "+ limit + "")
                elif len(ordonner) != 0 and limit != "NO" :
                    cur.execute("SELECT "+ S +" FROM " + select_table + " ORDER BY (" + T +") "+ ordre + " LIMIT " + limit + "")
                output = cur.fetchall()
        

    return render_template("lecture_ps.html", 
                            nom_table_ = nom_table,
                            etap_ = etap, 
                            select_table_ = select_table,
                            select_attribu_ = select_attribu,
                            ordonner_ = ordonner,
                            ordre_ = ordre,
                            limit_ = limit,
                            output_ = output
                            )

@app.route("/post_lecture_ps", methods = ['POST'])
def post_lecture_ps():
    global etap
    global select_table
    global select_attribu
    global ordonner
    global ordre
    global limit
    global output
    

    if etap == 0 :
        select_table = request.form.get("S1",None)
        etap = etap + 1
    elif etap == 1 :
        select_attribu = request.form.getlist("S2", None )
        etap = etap + 1
    elif etap == 2 :
        ordre = request.form.get("S3",None)
        ordonner = request.form.getlist("S4",None)
        etap = etap + 1
    elif etap == 3:
        limit = request.form.get("S5",None)
        etap = etap + 1
        print("+++++++++++++++")
        print(limit)
        print("+++++++++++++++")
    elif etap == 4:
        etap = 10
        
    
    return redirect(url_for("lecture_ps"))

@app.route("/restart_recherche_ps", methods = ['POST'])
def restart_recherche_ps():
    global etap
    global select_table
    global select_attribu
    global ordonner
    global ordre
    global limit
    global output
    

    etap = 0
    select_table = None
    select_attribu = None
    ordonner = None
    ordre = None
    limit = None
    output = None
    
    
    return redirect(url_for("lecture_ps"))

#===============================================================================
etap2 = 0
select_table = None
select_attribu = None
attribu_type = None
select_attribu_cp = None
inpt = None
out = "INSERTION REUSSI !!"


@app.route("/ecriture_ps")
def ecriture_ps():
    if "log_in" not in session:
        return redirect(url_for("page_connexion"))
    
    global etap2
    global select_table
    global select_attribu
    global attribu_type
    global select_attribu_cp
    global inpt
    global out

    nom_table = [
        "animal",
        "refuge",
        "soin",
        "particulier",
        "historique",
        "occupe",
        "arrive",
        "depart"
    ]

    if etap2 == 1 :
        if select_table == "animal":
            select_attribu = ["idani", "espece", "nom", "age", "sexe", "signes_dist", "fourriere_dorigine", "date_rejoint_spa"]
            attribu_type   = ["int", "str", "str", "int", "str", "str", "str", "str"]
            select_attribu_cp = select_attribu
        elif select_table == "refuge":
            select_attribu = ["idref", "nom", "code_postal", "adresse", "num_tele", "capacite", "matricule"]
            attribu_type   = ["int", "str", "str", "str", "str", "int", "int"]
            select_attribu_cp = select_attribu
        elif select_table == "soin":
            select_attribu = ["idsoi", "nom"]
            attribu_type   = ["int", "str"]
            select_attribu_cp = select_attribu
        elif select_table == "particulier":
            select_attribu = ["idpar", "nom", "prenom", "adresse", "num_tele"]
            attribu_type   = ["int", "str", "str", "str", "str"]
            select_attribu_cp = select_attribu
        elif select_table == "historique":
            select_attribu = ["idani", "idsoi", "matricule", "date_"]
            attribu_type   = ["int", "int", "int", "str"]
            select_attribu_cp = select_attribu
        elif select_table == "occupe":
            select_attribu = ["idref", "matricule", "nom_de_fonction"]
            attribu_type   = ["int", "int", "str"]
            select_attribu_cp = select_attribu
        elif select_table == "arrive":
            select_attribu = ["idani", "idref", "date_"]
            attribu_type   = ["int", "int", "str"]
            select_attribu_cp = select_attribu
        elif select_table == "depart":
            select_attribu = ["idani", "idref", "date_"]
            attribu_type   = ["int", "int", "str"]
            select_attribu_cp = select_attribu
        
        if select_table == "-- liste des tables --":
            etap2 = 0
    
    # distinger les types  (STRING ou INT)
    if etap2 == 3:
        for i in range(0,len(inpt),1):
            for j in range(0,len(select_attribu_cp),1):
                if select_attribu[i] == select_attribu_cp[j]:
                    if attribu_type[j] == "str":
                        inpt[i] = "'" + inpt[i] + "'"
                    else :
                        inpt[i] = "" + inpt[i] + ""
    # verifier que l'attribut espece est ben selecionnee
    if etap2 == 2 and select_table == "animal":
        if "espece" not in select_attribu:
            etap2 = 0

    # former les n-uplet (xx,yy,zz, ... )
    if etap2 == 3:
        S = ""
        T = ""
        for i in range(0,len(inpt),1):
            S += inpt[i]
            if i+1 < len(inpt):
                S += ","
        S = "(" + S + ")"
        
        for i in range(0,len(select_attribu),1):
            T += select_attribu[i]
            if i+1 < len(select_attribu):
                T += ","
        T = "(" + T + ")"

        print("S : " + S)
        print("T : " + T)
        print("SQL : " + "INSERT INTO " + select_table + T + " VALUES " + S)

        # le requette SQL pour inserer un enregistrement
        with db.connect() as conn:
            with conn.cursor() as cur:
                try :
                    cur.execute("INSERT INTO " + select_table + T + " VALUES " + S )
                except :
                    print("ERREUR SQL !!")
                    out = "ERREUR SQL !!"
                
    
    
    return render_template("ecriture_ps.html",
                            nom_table_ = nom_table,
                            etap_ = etap2,
                            select_table_ = select_table,
                            select_attribu_ = select_attribu,
                            out_ = out,
                            )

@app.route("/post_ecriture_ps", methods = ['POST'])
def post_ecriture_ps():
    global etap2
    global select_table
    global select_attribu
    global attribu_type
    global inpt
    global out

    if etap2 == 0:
        select_table = request.form.get("S1",None)
        etap2 +=1
    elif etap2 == 1:
        select_attribu = request.form.getlist("S2",None)
        etap2 +=1
    elif etap2 == 2:
        inpt = request.form.getlist("LST",None)
        etap2 +=1

    return redirect(url_for("ecriture_ps"))

@app.route("/restart_ecritur_ps", methods = ['POST'])
def restart_ecritur_ps():
    global etap2
    global select_table
    global select_attribu
    global attribu_type
    global inpt
    global out

    etap2 =0
    select_table = None
    select_attribu = None
    attribu_type = None
    inpt = None
    out = "INSERTION REUSSI !!"


    return redirect(url_for("ecriture_ps"))

#===============================================================================
#def initialise():
#    global etap
#    etap = 0


#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


if __name__ == '__main__':
    app.run()
