import psycopg2
import psycopg2.extras

def connect():
  conn = psycopg2.connect(
        dbname = "localdb",
        #host = "sqletud.u-pem.fr",
        #dbname = "mourad.tounsi_db",
        #password = "mouradBASE",
        
        cursor_factory = psycopg2.extras.NamedTupleCursor
  )
  conn.autocommit = True
  return conn

