
--
-- Drop tables (pour assurer de ne pas avoir les nom des tables avant la creation dans notre base )
--

DROP TABLE IF EXISTS animal CASCADE;
DROP TABLE IF EXISTS refuge CASCADE;
DROP TABLE IF EXISTS employe CASCADE;

DROP TABLE IF EXISTS soin CASCADE;
DROP TABLE IF EXISTS particulier CASCADE;

DROP TABLE IF EXISTS historique CASCADE;
DROP TABLE IF EXISTS occupe CASCADE;

DROP TABLE IF EXISTS arrive CASCADE;
DROP TABLE IF EXISTS depart CASCADE;

--
-- creer la table animal
--

CREATE TABLE animal(
    idANI serial,
    espece text,
    nom varchar(30),
    age numeric(2,0),
    sexe character(1),
    signes_dist text,
    fourriere_dorigine text,
    date_rejoint_SPA date,
    
    idPAR integer,
    date_adopte date,

    CONSTRAINT animal_CONT_1 PRIMARY KEY (idANI),
    CONSTRAINT animal_CONT_2 CHECK ( sexe = 'M' OR sexe = 'F' )
);

--
-- creer la table refuge
--

CREATE TABLE refuge(
    idREF serial,
    nom varchar(30),
    code_postal char(5),
    adresse varchar(100),
    num_Tele varchar(10),
    capacite integer,
    matricule integer,

    CONSTRAINT refuge_CONT_1 PRIMARY KEY (idREF)
);

--
-- creer la table employe
--

CREATE TABLE employe(
    matricule serial,
    nom varchar(30),
    prenom varchar(30),
    adresse varchar(100),
    num_Tele varchar(10),
    date_naiss date,
    num_sec varchar(15),
    date_arrive_SPA date,
    log_in varchar(100),
    mot_de_passe text,

    CONSTRAINT employe_CONT_1 PRIMARY KEY (matricule),
    CONSTRAINT employe_CONT_2 UNIQUE (log_in)
);

--
-- creer la table 
--

CREATE TABLE soin(
    idSOI serial,
    nom varchar(30),

    CONSTRAINT soin_CONT_1 PRIMARY KEY (idSOI)
);

--
-- creer la table particulier
--

CREATE TABLE particulier(
    idPAR serial,
    nom varchar(30),
    prenom varchar(30),
    adresse varchar(100),
    num_Tele varchar(10),

    CONSTRAINT particulier_CONT_1 PRIMARY KEY (idPAR)
);



--
-- creer la table historique
--

CREATE TABLE historique(
    idANI integer,
    idSOI integer,
    matricule integer,
    date_ date,

    CONSTRAINT historique_CONT_1 PRIMARY KEY (idANI,idSOI,matricule,date_)
);

--
-- creer la table occupe
--

CREATE TABLE occupe(
    matricule integer,
    idREF integer,
    nom_de_fonction text,

    CONSTRAINT occupe_CONT_1 PRIMARY KEY (matricule,idREF,nom_de_fonction)
);

--
-- creer la table arrive
--

CREATE TABLE arrive(
    idANI integer,
    idREF integer,
    date_ date,

    CONSTRAINT arrive_CONT_1 PRIMARY KEY (idANI,idREF,date_)
);

--
-- creer la table depart
--

CREATE TABLE depart(
    idANI integer, 
    idREF integer, 
    date_ date,

    CONSTRAINT depart_CONT_1 PRIMARY KEY (idANI,idREF,date_)
);


--
-- Ajouter les contraintes (clefs etrangeres)
--

---------------------------------------------------------------------------------------------
ALTER TABLE animal
ADD CONSTRAINT animal_CONT_3 FOREIGN KEY (idPAR) REFERENCES particulier(idPAR)
ON DELETE CASCADE ON UPDATE CASCADE;
---------------------------------------------------------------------------------------------
ALTER TABLE refuge
ADD CONSTRAINT refuge_CONT_2 FOREIGN KEY (matricule) REFERENCES employe(matricule)
ON DELETE CASCADE ON UPDATE CASCADE;
---------------------------------------------------------------------------------------------
ALTER TABLE historique
ADD CONSTRAINT historique_CONT_2 FOREIGN KEY (idANI) REFERENCES animal(idANI)
ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE historique
ADD CONSTRAINT historique_CONT_3 FOREIGN KEY (idSOI) REFERENCES soin(idSOI)
ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE historique
ADD CONSTRAINT historique_CONT_4 FOREIGN KEY (matricule) REFERENCES employe(matricule)
ON DELETE CASCADE ON UPDATE CASCADE;
---------------------------------------------------------------------------------------------
ALTER TABLE occupe
ADD CONSTRAINT occupe_CONT_2 FOREIGN KEY (matricule) REFERENCES employe(matricule)
ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE occupe
ADD CONSTRAINT occupe_CONT_3 FOREIGN KEY (idREF) REFERENCES refuge(idREF)
ON DELETE CASCADE ON UPDATE CASCADE;
---------------------------------------------------------------------------------------------
ALTER TABLE arrive
ADD CONSTRAINT arrive_CONT_2 FOREIGN KEY (idANI) REFERENCES animal(idANI)
ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE arrive
ADD CONSTRAINT arrive_CONT_3 FOREIGN KEY (idREF) REFERENCES refuge(idREF)
ON DELETE CASCADE ON UPDATE CASCADE;
---------------------------------------------------------------------------------------------
ALTER TABLE depart
ADD CONSTRAINT depart_CONT_2 FOREIGN KEY (idANI) REFERENCES animal(idANI)
ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE depart
ADD CONSTRAINT depart_CONT_3 FOREIGN KEY (idREF) REFERENCES refuge(idREF)
ON DELETE CASCADE ON UPDATE CASCADE;
---------------------------------------------------------------------------------------------

--
-- Ajouter les contraintes (NOT NULL)
--

-- un refuge doit toujours avoir un gerant 
ALTER TABLE refuge
ALTER COLUMN matricule SET NOT NULL;

ALTER TABLE refuge
ALTER COLUMN capacite SET NOT NULL;



--
-- Inserer la DATA (enregistrements)
--


/*Particulier*/
insert into particulier values (100,'Durache','Theo','42 avenue du pré fleuri','0629915349');
insert into particulier values (101,'Domino','Julie','34 avenue anatole france','0724918591');
insert into particulier values (102,'Blanche','Raphael','5 avenue fauvette','0612421736');
insert into particulier values (103,'Cherrak','Imen','1 bis avenue tournesol','0781686259');

/*animal*/
insert into animal(idani,espece,nom,age,sexe,fourriere_dorigine,date_rejoint_spa,idPAR,date_adopte) 
values (1500,'chien','Rex',3,'M','Refuge du Chesnay','2019-10-9',100,'2017-10-9');

insert into animal(idani,espece,nom,age,sexe,signes_dist,fourriere_dorigine,date_rejoint_spa) 
values (1501,'chien','Hector',12,'M','Emputé de la patte droite','Refuge des cignes', '2020-2-23');

insert into animal(idani,espece,nom,age,sexe,signes_dist,date_rejoint_spa,idPAR,date_adopte) 
values (1502,'chien','Volt',4,'M','oeil vairon', '2019-5-4', 102,'2021-11-3');

insert into animal(idani,espece,nom,age,sexe,date_rejoint_spa,idPAR,date_adopte) 
values (1503,'chat','viky',5,'F','2017-5-4', 102,'2018-09-09');

insert into animal(idani,espece,nom,age,sexe,date_rejoint_spa,idPAR,date_adopte) 
values (1504,'poule','pim-pim',3,'F','2019-5-4', 103,'2021-09-09');

insert into animal(idani,espece,nom,age,sexe,date_rejoint_spa) 
values (1505,'tortue','mbappe',2,'M','2020-3-3');

/*Employe*/
insert into employe(nom,prenom,adresse,num_tele,date_naiss,num_sec,date_arrive_spa,log_in,mot_de_passe) 
values ('Forestier','Florence','56 rue gingembre','0605040187','1990-10-9','1313131313132','2004-4-4','Florence.Forestier','coucou1');

insert into employe (nom,prenom,adresse,num_tele,date_naiss,num_sec,date_arrive_spa,log_in,mot_de_passe) 
values('Speedyboy','Luc','4bis avenue Eugène Verlain','0695745517','1988-1-22','2323232323232','2008-6-4','Speedyboy.Luc','chien1988');

insert into employe (nom,prenom,adresse,num_tele,date_naiss,num_sec,date_arrive_spa,log_in,mot_de_passe) 
values ('Foret','Nihed','33 rue Armistice','0795949187','2001-9-14','2325139317136','2021-12-29','Foret.Nihed','Algerie');

insert into employe (nom,prenom,adresse,num_tele,date_naiss,num_sec,date_arrive_spa,log_in,mot_de_passe) 
values ('Foret','Billel','13 rue de la Liberation','0795999957','1969-5-3','4758939322119','2000-6-7','Foret.Billel','NihedMaFille');

insert into employe (nom,prenom,adresse,num_tele,date_naiss,num_sec,date_arrive_spa,log_in,mot_de_passe) 
values ('Camescass','Anais','795 avenue Barbara','0643952926','1960-5-24','4760803329719','2006-1-1','Camescass.Anais','gribouille22');

insert into employe (nom,prenom,adresse,num_tele,date_naiss,num_sec,date_arrive_spa,log_in,mot_de_passe) 
values ('Boris','Abou','8 avenue brik','0611959926','1999-5-24','0360896329719','2017-8-1','Boris.Abou','Boris33');

insert into employe (nom,prenom,adresse,num_tele,date_naiss,num_sec,date_arrive_spa,log_in,mot_de_passe) 
values ('Benoit','Lea','87 avenue louange','0711958306','1989-7-22','0760146328719','2019-8-17','Benoit.Lea','Leacoeur');

/*refuge*/--19243
insert into refuge 
values(1001,'SPA de Vaux-Le-Penil','65298','2 rue les prés Neufs','0184596324',200,1);

insert into refuge 
values(1002,'SPA de Marennes - Lyon','65298','660 chemin de Chantemerle','0166566726',200,2);

insert into refuge 
values(1003,'Dispensaire SPA de Toulon','32548','32 rue Bertier','0166566726',80,3);

insert into refuge 
values(1004,'Dispensaire SPA de Toulouse','94140','3 impasse de Sicile','0969568168',110,4);

/*Soins*/
insert into soin values (1, 'Vaccins');
--insert into soin values (2, 'Rappel');
insert into soin values (3, 'Vermifuge');
insert into soin values (4, 'Sterilisation');
insert into soin values (5, 'Detartrage');
insert into soin values (6, 'Coupage des griffes');

/*occupe*/
insert into occupe(idref,matricule,nom_de_fonction) values (1001, 1, 'veterinaire');
insert into occupe(idref,matricule,nom_de_fonction) values (1002, 2, 'Gerant');
insert into occupe(idref,matricule,nom_de_fonction) values (1001, 3, 'Agent Animalier');
insert into occupe(idref,matricule,nom_de_fonction) values (1002, 2, 'Veterinaire');
insert into occupe(idref,matricule,nom_de_fonction) values (1003, 4, 'Barman');
insert into occupe(idref,matricule,nom_de_fonction) values (1003, 3, 'Assistant Veterinaire');


/*historique*/
insert into historique values (1500, 3, 2, '2019-12-24');
insert into historique values (1502, 1, 1, '2021-4-6');
insert into historique values (1503, 6, 1, '2020-9-9');
insert into historique values (1504, 1, 3, '2022-4-6');
insert into historique values (1504, 4, 5, '2021-7-3');
insert into historique values (1504, 1, 3, '2021-3-4');
insert into historique values (1504, 1, 3, '2021-11-12');

--insert into historique values (1502, 1, 3, '2022-11-29');




/*Depart*/
insert into depart(idani, idref,date_) values(1500,1001,'2020-12-12');
insert into depart(idani, idref,date_) values(1500,1002,'2022-4-6');
insert into depart(idani, idref,date_) values(1503,1003,'2020-8-8');
insert into depart(idani, idref,date_) values(1505,1004,'2021-5-6');
insert into depart(idani, idref,date_) values(1500,1001,'2021-12-12');

/*arrive*/
insert into arrive(idani,idref,date_) values(1500,1002,'2020-1-5');
insert into arrive(idani,idref,date_) values(1500,1001,'2020-9-8');
insert into arrive(idani,idref,date_) values(1503,1001,'2020-2-23');
insert into arrive(idani,idref,date_) values(1500,1003,'2022-8-8');

insert into arrive(idani,idref,date_) values(1501,1003,'2021-2-11');
insert into arrive(idani,idref,date_) values(1504,1002,'2019-3-24');
insert into arrive(idani,idref,date_) values(1502,1004,'2020-7-1');
insert into arrive(idani,idref,date_) values(1505,1004,'2018-5-2');
insert into arrive(idani,idref,date_) values(1505,1003,'2020-11-17');


--
-- VIEW 
--
-- animaux non vaccines
CREATE VIEW V1 AS(
    SELECT animal.* 
    FROM animal
    EXCEPT
    SELECT animal.*
    FROM animal , historique , soin
    WHERE (soin.idSOI = historique.idSOI AND animal.idANI = historique.idANI)
    AND   (soin.nom = 'Vaccins')
);

-- rappel de vaccination 15 Jours
CREATE VIEW V2 AS(
    WITH tab1 AS(
        select idANI, max(date_) AS dt
        FROM historique 
        WHERE idSOI = 1   -- 1 : Vaccins
        GROUP BY idANI
    )
    SELECT animal.*,tab1.dt
    FROM tab1 NATURAL JOIN animal
    WHERE (CURRENT_DATE - dt > 15)
);




--insert into animal(idani,espece,nom,age,sexe,signes_dist,fourriere_dorigine,date_rejoint_spa) 
--values (1501,'chien','Hector',12,'M','Emputé de la patte droite','Refuge des cignes', '2020-2-23');

--insert into animal(idani,espece,nom,age,sexe,signes_dist,date_rejoint_spa,idPAR,date_adopte) 
--values (1502,'chien','Volt',4,'M','oeil vairon', '2019-5-4', 102,'2021-11-3');

--insert into animal(idani,espece,nom,age,sexe,date_rejoint_spa,idPAR,date_adopte) 
--values (1504,'poule','pim-pim',3,'F','2019-5-4', 103,'2021-09-09');

--insert into animal(idani,espece,nom,age,sexe,date_rejoint_spa) 
--values (1505,'tortue','mbappe',2,'M','2020-3-3');

--1001
--1002
--1003
--1004
--
-- creation des VIEW
--

--CREATE VIEW V1 AS(
--    SELECT idANI
--    FROM soin NATURAL JOIN historique NATURAL JOIN animal NATURAL JOIN dates
--    WHERE nom_s = 'Vaccins'
--);

